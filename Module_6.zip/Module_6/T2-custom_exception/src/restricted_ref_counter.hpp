// copy your implementation from the last round here (if you had one and used it)
// and wrap it inside a WeirdMemoryAllocator namespace

